package com.example.demo18;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.*;
import java.util.Random;
import java.util.ResourceBundle;

public class AddBook implements Initializable {
    public TextField bookId3;
    public TextField bookName3;
    public TextField Quantity;
    public Label label1;
    public int count = 1;
    public StringBuilder labelNumber;
    public StringBuilder theBookLabel;
    public Button submitbutton;
    public Button deleteButton;
    public RadioButton toggle;
    public TextField BookLabel;
    private String NumberOfBooks;


    public void submit1() {
        if (!bookId3.getText().isEmpty() && !bookName3.getText().isEmpty() && !Quantity.getText().isEmpty()) {
            if(MyException.checkIfInteger(bookId3.getText())&&MyException.checkIfInteger(Quantity.getText())) {
                if (!Checker()&&!CheckerForID()) {
                    DatabaseConnection connection3 = new DatabaseConnection();
                    Connection connectionDB3 = connection3.getConnection();
                    String BookName = bookName3.getText();
                    String BookID = bookId3.getText();

                    String commandInsert = "insert into booksavailable (book_id,book_name,number_book_available)values(?,?,?)";
                    String commandInsert1 = "insert into popularity (book_name,number_of_time_booked)values(?,0)";
                    try {
                        PreparedStatement preparedStatement4 = connectionDB3.prepareStatement(commandInsert);
                        PreparedStatement preparedStatement = connectionDB3.prepareStatement(commandInsert1);
                        preparedStatement4.setString(1, BookID);
                        preparedStatement4.setString(2, BookName);
                        preparedStatement4.setString(3, Quantity.getText());
                        preparedStatement.setString(1, BookName);
                        preparedStatement4.executeUpdate();
                        preparedStatement.executeUpdate();
                        addLabelToBooks();
                        bookId3.setText("");
                        bookName3.setText("");
                        Quantity.setText("");
                        preparedStatement.close();
                        preparedStatement4.close();
                        connectionDB3.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                } else if (CheckerForID()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setContentText("The book Id is already present");
                    alert.show();
                }else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Books Info is present in DataBase.Try Updating avoiding duplicates");
                    alert.show();
                }
            }else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Wrong data type");
                alert.show();
            }
    }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill the empty Fields");
            alert.show();
        }
    }
    public void update1() {
        if (!bookId3.getText().isEmpty() && !Quantity.getText().isEmpty()) {
            if(MyException.checkIfInteger(bookId3.getText())&&MyException.checkIfInteger(Quantity.getText())) {
                if (Checker()) {
                    DatabaseConnection connection3 = new DatabaseConnection();
                    Connection connectionDB3 = connection3.getConnection();
                    String BookName = bookName3.getText();
                    String BookID = bookId3.getText();
                    Integer Quantity1 = Integer.valueOf(Quantity.getText());

                    String commandInsert = "update booksavailable set number_book_available = number_book_available+? where book_id = ? and book_name = ?";

                    try {
                        PreparedStatement preparedStatement4 = connectionDB3.prepareStatement(commandInsert);
                        preparedStatement4.setString(1, String.valueOf(Quantity1));
                        preparedStatement4.setString(2, BookID);
                        preparedStatement4.setString(3, BookName);
                        preparedStatement4.executeUpdate();

                        bookName3.setText("");
                        bookId3.setText("");
                        Quantity.setText("");
                        preparedStatement4.close();
                        connectionDB3.close();

                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Books to be Updated does not Exists in DataBase. Try Adding It!");
                    alert.show();
                }
            }else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Wrong data type");
                alert.show();
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill The Empty Fields");
            alert.show();
        }
    }
    public boolean Checker(){
        boolean isPresent = false;
        DatabaseConnection connection5 = new DatabaseConnection();
        Connection connectionDB5 = connection5.getConnection();
        String command = "select * from booksavailable where book_name = ? and book_id=?";
        try{
            PreparedStatement preparedStatement5 = connectionDB5.prepareStatement(command);
            preparedStatement5.setString(1,bookName3.getText());
            preparedStatement5.setString(2,bookId3.getText());
            ResultSet set5 = preparedStatement5.executeQuery();
            if(set5.next()){
                isPresent = true;
            }
            set5.close();
            preparedStatement5.close();
            preparedStatement5.close();
            connectionDB5.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
        return isPresent;
    }
    public boolean CheckerForID() {

        DatabaseConnection connection5 = new DatabaseConnection();
        Connection connectionDB5 = connection5.getConnection();
        String command = "select count(*) from booksavailable where book_id = ? ";
        try {
            PreparedStatement preparedStatement5 = connectionDB5.prepareStatement(command);
            preparedStatement5.setString(1,bookId3.getText());
            ResultSet set5 = preparedStatement5.executeQuery();
            if (set5.next()) {
                int count = set5.getInt(1);
                return count > 0;
            }
            set5.close();
            preparedStatement5.close();
            connectionDB5.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public void addLabelToBooks(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command = "insert into book_available_label(book_id,book_name,book_label) values(?,?,?)";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            while( count <= Integer.parseInt(Quantity.getText())){
                preparedStatement.setString(1, bookId3.getText());
                preparedStatement.setString(2, bookName3.getText());
                preparedStatement.setString(3,getLabelNumber());
                preparedStatement.executeUpdate();
                count++;
            }
            Quantity.setText("");
            bookName3.setText("");
            bookId3.setText("");
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void goBack6(ActionEvent event) throws Exception {
        DatabaseConnection.changeScene(event, "OptionScene.fxml");
    }

    public String getLabelNumber() {
        int Sum = 1;
        DatabaseConnection connection = new DatabaseConnection();
        Connection connection1 = connection.getConnection();
        String command = "update book_available_label set book_label = ? where book_id = 0";
        String command1 = "select book_label from book_available_label where book_id = 0";
        String TheLabel = null;
        try {
            PreparedStatement preparedStatement = connection1.prepareStatement(command);
            PreparedStatement preparedStatement1 = connection1.prepareStatement(command1);
            ResultSet resultSet = preparedStatement1.executeQuery();
            while (resultSet.next()) {
                int Start = Integer.parseInt(resultSet.getString(1));
                Sum = Start + 1;
                TheLabel = "";
                String Book = bookName3.getText();
                theBookLabel = new StringBuilder();
                if(bookName3.getText().length()>2){
                    for (int i = 0; i < 2; i++) {
                        char character = Book.charAt(i);
                        theBookLabel.append(character);
                    }
                }else{
                    theBookLabel.append(Book);
                }
                TheLabel = String.valueOf(theBookLabel).toUpperCase() + Sum;
            }
            preparedStatement.setString(1, String.valueOf(Sum));
            preparedStatement.executeUpdate();
            connection1.close();
            preparedStatement.close();
            preparedStatement1.close();
            resultSet.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return TheLabel;
    }
    public  int numberBooksAvailable1() {
        DatabaseConnection connection = new DatabaseConnection();
        Connection connectionDB5 = connection.getConnection();
        String command = "select * from booksavailable where book_name = ? and book_id=?";
        int bookAvailable = 0;
        try {
            PreparedStatement preparedStatement5 = connectionDB5.prepareStatement(command);
            preparedStatement5.setString(1, bookName3.getText());
            preparedStatement5.setString(2, bookId3.getText());
            ResultSet set5 = preparedStatement5.executeQuery();
            if (set5.next()) {
                bookAvailable = set5.getInt(3);
            }
            connectionDB5.close();
            preparedStatement5.close();
            set5.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookAvailable;
    }
    public void deleteBooksAvailable(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
       if(setToggle()==false){
           if (bookName3.getText().isEmpty()){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Fill the BookName");
               alert.show();
               return;
           }
           if (bookId3.getText().isEmpty()){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Fill the Book ID");
               alert.show();
               return;
           }
           if(Quantity.getText().isEmpty()){
               Alert alert = new Alert(Alert.AlertType.WARNING);
               alert.setContentText("Enter Number of Books To be Deleted");
               alert.show();
               return;
           }
           if(!MyException.checkIfInteger(bookId3.getText())){
               Alert alert = new Alert(Alert.AlertType.WARNING);
               alert.setContentText("Wrong data type");
               alert.show();
               return;
           }
           if(!MyException.checkIfInteger(Quantity.getText())){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Wrong data type");
               alert.show();
               return;}
           else{
               NumberOfBooks = Quantity.getText();
           }
           if (Checker()==false){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Book Not Available in DataBase");
               alert.show();
               return;
           }

            int difference = numberBooksAvailable1() - Integer.parseInt(NumberOfBooks);
            System.out.println(difference);
            if(difference >= 0) {

                String command = "update booksavailable set number_book_available = ? where book_name = ? and book_id = ? ";
                String command1 = "delete from book_available_label where book_id = ? limit " + Integer.parseInt(Quantity.getText());
                PreparedStatement preparedStatement;
                try {

                    preparedStatement = connection.prepareStatement(command);
                    PreparedStatement preparedStatement1 = connection.prepareStatement(command1);
                    preparedStatement.setString(1, String.valueOf(difference));
                    preparedStatement.setString(2, bookName3.getText());
                    preparedStatement.setString(3, bookId3.getText());
                    preparedStatement1.setString(1, bookId3.getText());
                    preparedStatement1.executeUpdate();
                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                    connection.close();

                    bookName3.setText("");
                    bookId3.setText("");
                    Quantity.setText("");
                    preparedStatement.close();
                    connection.close();
                    System.out.println("HH");
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }else {
                 Alert alert = new Alert(Alert.AlertType.ERROR);
                 alert.setContentText("Books are not of that Quantity.Only " + numberBooksAvailable1() +
                        " are present is the data base.");
                 alert.show();
            }

       }else {
           if(Checker()==false){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Book not available in DataBase");
               alert.show();
               return;
           }
           if(!BookLabel.getText().isEmpty()){
               String command4 = "select * from book_available_label where book_label = ? ";
               String command2 = "update booksavailable set number_book_available = number_book_available - 1 where book_name = ? and book_id = ? ";
               String command3 = "delete from book_available_label where book_label = ?";
               try {
                   PreparedStatement preparedStatement4 = connection.prepareStatement(command4);
                   preparedStatement4.setString(1,BookLabel.getText());
                   ResultSet resultSet = preparedStatement4.executeQuery();
                   if(!resultSet.next()){
                       Alert alert = new Alert(Alert.AlertType.ERROR);
                       alert.setContentText("The Book Label not present");
                       alert.show();
                       return;
                   }
                   while (resultSet.next()){
                       PreparedStatement preparedStatement = connection.prepareStatement(command2);
                       PreparedStatement preparedStatement1 = connection.prepareStatement(command3);
                       preparedStatement.setString(1,bookName3.getText());
                       preparedStatement.setString(2,bookId3.getText());
                       preparedStatement1.setString(1,BookLabel.getText());
                       preparedStatement.executeUpdate();
                       preparedStatement1.executeUpdate();
                       connection.close();
                       preparedStatement.close();
                       resultSet.close();
                   }

               }catch (SQLException e){
                   e.printStackTrace();
               }
           }

       }

    }
    public boolean setToggle(){
        return toggle.isSelected();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        BookLabel.setEditable(false);
        toggle.selectedProperty().addListener(new ChangeListener<>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                if(oldValue){
                    Quantity.setEditable(true);
                    BookLabel.setText(null);
                    BookLabel.setEditable(false);
                }else {
                    Quantity.setText(null);
                    Quantity.setEditable(false);
                    BookLabel.setEditable(true);
                }
            }
        });
    }
}

