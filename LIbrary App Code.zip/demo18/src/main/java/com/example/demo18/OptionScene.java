package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;

public class OptionScene  {
    public Button Borrow;
    public Button Return;

    //All below methods are used to change page from one to another they use "change scene" function that is already declared in the database connection class
    //it is done through passing the event and fxml file as parameter example in loadToAddBooks methods the parameter are "events" and "AddBook.fxml"
    //It is the same for all method in this class with same function but switch to different pages
    public void loadToAddBooks(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"AddBook.fxml");
    }

    public  void loadToReturnedBooks(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"ReturnedBookList.fxml");
    }

    public  void loadToAvailableBooks(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"AvailableBooks.fxml");

    }
    public  void loadToBookedBooks(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"BookedBooks.fxml");
    }
    public  void toBorrowForm(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"Form.fxml");
    }
    public  void toReturnForm(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"ReturnForm.fxml");
    }
    public  void backToLogin(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"LoginPage.fxml");
    }

}
