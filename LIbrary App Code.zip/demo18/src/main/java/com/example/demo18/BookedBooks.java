package com.example.demo18;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class BookedBooks implements Initializable  {

    public  TableView<Table1> tableView;
    public  TableColumn<Table1, String> ColStudent_ID;
    public  TableColumn<Table1,String> ColStudent_Name;
    public  TableColumn<Table1,String> ColBookBorrowed;
    public  TableColumn<Table1,Integer> ColBook_ID;
    public  TableColumn<Table1,String> ColBorrowedDate;
    public Button back1;
    public TableColumn<Table1, String> ColLibrarian;
    public TableColumn<Table1,String > ColBookLabel;
    public TextField StudentName;
    public Button search;
    private ObservableList<Table1> bookedBooksList;
    public String student;
    public String student1;

    //It is the method that load the table and assign the data as soon as you change to the available books page in the option page


    public void initialize(URL url, ResourceBundle resourceBundle) {
      recall();
    }
    //The change scene or page back to the option scene from the booked books page
    public void goBack(ActionEvent event) throws IOException {
        DatabaseConnection.changeScene(event,"OptionScene.fxml");
    }
    public  void recall(){
        MyException myException = new MyException();
        if(StudentName.getText().isEmpty()){
            refresh();
        }else{
            student = StudentName.getText();
            if(myException.checkIfInteger(student)){
                student1 = student;
                certainStudent();
                StudentName.setText("");
            }else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Wrong data value");
                alert.show();
            }

        }
    }

    public void refresh(){
        DatabaseConnection connection1 = new DatabaseConnection();
        Connection connectDB = connection1.getConnection();
        String command1 = "select * from booked_books";

        try {
            bookedBooksList = FXCollections.observableArrayList();
            ResultSet resultSet = connectDB.createStatement().executeQuery(command1);
            while (resultSet.next()) {
                bookedBooksList.add(new Table1(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getInt(4), resultSet.getString(5),resultSet.getString(6),resultSet.getString(7)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ColStudent_ID.setCellValueFactory(new PropertyValueFactory<>("Student_ID"));
        ColStudent_Name.setCellValueFactory(new PropertyValueFactory<>("Student_Name"));
        ColBookBorrowed.setCellValueFactory(new PropertyValueFactory<>("BookBorrowed"));
        ColBook_ID.setCellValueFactory(new PropertyValueFactory<>("Book_ID"));
        ColBorrowedDate.setCellValueFactory(new PropertyValueFactory<>("BorrowedDate"));
        ColLibrarian.setCellValueFactory(new PropertyValueFactory<>("Librarian"));
        ColBookLabel.setCellValueFactory(new PropertyValueFactory<>("BookLabel"));
        tableView.setItems(null);
        tableView.setItems(bookedBooksList);

    }
    public void certainStudent(){
        DatabaseConnection connection1 = new DatabaseConnection();
        Connection connectDB = connection1.getConnection();
        String command1 = "select * from booked_books where student_ID = ?";

        try {
            bookedBooksList = FXCollections.observableArrayList();
            PreparedStatement preparedStatement = connectDB.prepareStatement(command1);
            preparedStatement.setString(1,student1);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                bookedBooksList.add(new Table1(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getInt(4), resultSet.getString(5),resultSet.getString(6),resultSet.getString(7)));
            }
        }

        catch (SQLException e) {
            e.printStackTrace();
        }
        ColStudent_ID.setCellValueFactory(new PropertyValueFactory<>("Student_ID"));
        ColStudent_Name.setCellValueFactory(new PropertyValueFactory<>("Student_Name"));
        ColBookBorrowed.setCellValueFactory(new PropertyValueFactory<>("BookBorrowed"));
        ColBook_ID.setCellValueFactory(new PropertyValueFactory<>("Book_ID"));
        ColBorrowedDate.setCellValueFactory(new PropertyValueFactory<>("BorrowedDate"));
        ColLibrarian.setCellValueFactory(new PropertyValueFactory<>("Librarian"));
        ColBookLabel.setCellValueFactory(new PropertyValueFactory<>("BookLabel"));
        tableView.setItems(null);
        tableView.setItems(bookedBooksList);

    }


}