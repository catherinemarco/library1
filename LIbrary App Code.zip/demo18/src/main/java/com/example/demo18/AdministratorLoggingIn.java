package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class AdministratorLoggingIn extends ReturnForm implements Initializable {
    public Button adminButtonLogin;
    public PasswordField adminPasswordnew;
    public PasswordField adminPasswordold;
    public Button adminButtonClear1;
    public TextField newLimit;
    public Button backToWelcome;
    public Text periodLimit;
    public Button changeLoanPeriod;
    public Button changeLoanPeriod1;
    public TextField newBookLimit;
    public Text noBookLimit;



    public void loadToRegister(ActionEvent event)throws IOException {
        DatabaseConnection.changeScene(event,"Register.fxml");
    }
    public void changePassword(){
        if(!adminPasswordnew.getText().isEmpty() && !adminPasswordold.getText().isEmpty()) {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection Connect1DB = connectNow.getConnection();
            String AdministratorName = "Administrator";

            String Command = "  select * from userinfo where username = ?" ;
            String Command1 = "update userinfo set password1 = ? where password1 = ?";
            try{
                PreparedStatement preparedStatement = Connect1DB.prepareStatement(Command1);
                PreparedStatement preparedStatement1 = Connect1DB.prepareStatement(Command);
                preparedStatement1.setString(1,AdministratorName);
                ResultSet resultSet = preparedStatement1.executeQuery();
                while(resultSet.next()){
                    if(adminPasswordold.getText().equals(resultSet.getString(2))){
                        preparedStatement.setString(1,adminPasswordnew.getText());
                        preparedStatement.setString(2,adminPasswordold.getText());
                        preparedStatement.executeUpdate();
                        adminPasswordold.setText("");
                        adminPasswordnew.setText("");

                    }else{
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setContentText("Wrong credential");
                        alert.show();
                    }
                }
                resultSet.close();
                preparedStatement.close();
                Connect1DB.close();
            }
            catch (SQLException e){
                e.printStackTrace();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("The Old Password is Wrong");
            alert.show();

        }
    }

    public void setAdminButtonClear(){
        adminPasswordnew.setText("");
        adminPasswordold.setText("");
    }
    public void setChangeLoanPeriod(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command = "update _limit set _number = ? where _name = ? ";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            preparedStatement.setString(1,newLimit.getText());
            preparedStatement.setString(2,"daylimit");
            preparedStatement.executeUpdate();
            periodLimit.setText(ReturnForm.getNumberOfDays() + " days");
            newLimit.setText("");
            preparedStatement.close();
            connection.close();

        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public static int getReturnBookLimit(){
        int Max_number_Books = 0;
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String Command = "select count from student_count where student_id = 'Max Number of Books' ";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(Command);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                Max_number_Books = resultSet.getInt(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return Max_number_Books;
    }
    public void setMaxNumberOfBooksLentPerStudent() {
        if(MyException.checkIfInteger(newBookLimit.getText())) {
            DatabaseConnection databaseConnection = new DatabaseConnection();
            Connection connection = databaseConnection.getConnection();
            String command = "update student_count set count = ? where student_id = 'Max Number of Books' ";
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(command);
                preparedStatement.setString(1, newBookLimit.getText());
                preparedStatement.executeUpdate();
                noBookLimit.setText(getReturnBookLimit() + " Books");
                newBookLimit.setText("");
                preparedStatement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Wrong data type");
            alert.show();
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        periodLimit.setText(ReturnForm.getNumberOfDays() + " days");
        noBookLimit.setText(getReturnBookLimit() + " Books");

    }
}
