package com.example.demo18;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Table3 {
    public SimpleStringProperty Book_id;
    public SimpleStringProperty Book_name;
    public SimpleIntegerProperty Number_books_available;

    public Table3(String Book_id,String Book_name,Integer Number_books_available){
        this.Book_id = new SimpleStringProperty(Book_id);
        this.Book_name = new SimpleStringProperty(Book_name);
        this.Number_books_available = new SimpleIntegerProperty(Number_books_available);
    }

    public void setBook_id(String book_id) {
        this.Book_id.set(book_id);
    }

    public void setBook_name(String book_name) {
        this.Book_name.set(book_name);
    }

    public void setNumber_books_available(String number_books_available) {
        this.Number_books_available.set(Integer.parseInt(number_books_available));
    }

    public String getBook_id() {
        return Book_id.get();
    }

    public SimpleStringProperty book_idProperty() {
        return Book_id;
    }

    public String getBook_name() {
        return Book_name.get();
    }

    public SimpleStringProperty book_nameProperty() {
        return Book_name;
    }

    public int getNumber_books_available() {
        return Number_books_available.get();
    }

    public SimpleIntegerProperty number_books_availableProperty() {
        return Number_books_available;
    }
}
