package com.example.demo18;

public class MyException {
    public static boolean checkIfInteger(String data){
        for(char c: data.toCharArray()){
            if(!Character.isDigit(c)){
                return false;
            }
        }
        return true;
    }

}
