package com.example.demo18;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Table2 {
    public SimpleStringProperty Student_ID1;
    public SimpleStringProperty Student_Name1;
    public SimpleStringProperty BookBorrowed1;
    public SimpleIntegerProperty Book_ID1;
    public SimpleStringProperty Date_returned;
    public SimpleStringProperty Date_was_booked;
    public SimpleStringProperty Librarian;
    public SimpleStringProperty BookLabel;
    public SimpleStringProperty Librarian2;



    public Table2(String Student_ID1, String Student_Name1, String BookBorrowed1, int Book_ID1,
                  String Date_returned1, String Date_was_booked, String BookLabel, String Librarian,String Librarian2){
        this.Student_ID1 = new SimpleStringProperty(Student_ID1);
        this.Student_Name1 = new SimpleStringProperty(Student_Name1);
        this.BookBorrowed1 = new SimpleStringProperty(BookBorrowed1);
        this.Book_ID1 = new SimpleIntegerProperty(Book_ID1);
        this.Date_returned = new SimpleStringProperty(Date_returned1);
        this.Date_was_booked = new SimpleStringProperty(Date_was_booked);
        this.BookLabel = new SimpleStringProperty(BookLabel);
        this.Librarian = new SimpleStringProperty(Librarian);
        this.Librarian2 = new SimpleStringProperty(Librarian2);

    }
    public String getLibrarian() {
        return Librarian.get();
    }

    public SimpleStringProperty librarianProperty() {
        return Librarian;
    }

    public void setLibrarian(String librarian) {
        this.Librarian.set(librarian);
    }

    public String getBookLabel() {
        return BookLabel.get();
    }

    public SimpleStringProperty bookLabelProperty() {
        return BookLabel;
    }

    public void setBookLabel(String bookLabel) {
        this.BookLabel.set(bookLabel);
    }

    public String getStudent_ID1() {
        return Student_ID1.get();
    }

    public SimpleStringProperty student_ID1Property() {
        return Student_ID1;
    }

    public String getStudent_Name1() {
        return Student_Name1.get();
    }

    public SimpleStringProperty student_Name1Property() {
        return Student_Name1;
    }

    public String getBookBorrowed1() {
        return BookBorrowed1.get();
    }

    public SimpleStringProperty bookBorrowed1Property() {
        return BookBorrowed1;
    }

    public int getBook_ID1() {
        return Book_ID1.get();
    }

    public SimpleIntegerProperty book_ID1Property() {
        return Book_ID1;
    }

    public String getDate_returned() {
        return Date_returned.get();
    }

    public SimpleStringProperty date_returnedProperty() {
        return Date_returned;
    }

    public void setStudent_ID1(String student_ID1) {
        this.Student_ID1.set(student_ID1);
    }

    public void setStudent_Name1(String student_Name1) {
        this.Student_Name1.set(student_Name1);
    }

    public void setBookBorrowed1(String bookBorrowed1) {
        this.BookBorrowed1.set(bookBorrowed1);
    }

    public void setBook_ID1(int book_ID1) {
        this.Book_ID1.set(book_ID1);
    }

    public void setDate_returned(String date_returned) {
        this.Date_returned.set(date_returned);
    }

    public String getDate_was_booked() {
        return Date_was_booked.get();
    }

    public SimpleStringProperty date_was_bookedProperty() {
        return Date_was_booked;
    }

    public void setDate_was_booked(String date_was_booked) {
        this.Date_was_booked.set(date_was_booked);
    }

    public String getLibrarian2() {
        return Librarian2.get();
    }

    public SimpleStringProperty librarian2Property() {
        return Librarian2;
    }

    public void setLibrarian2(String librarian2) {
        this.Librarian2.set(librarian2);
    }
}
