package com.example.demo18;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.ResourceBundle;

public class AvailableBooks implements Initializable {
    //Its contains attribute of the table and the text components
    public TableView<Table3> table3TableView;
    public TableColumn<Table3,String> ColBookId2;
    public TableColumn<Table3,String> ColBookName2;
    public TableColumn<Table3,Integer> ColNumberAvailable2;
    public DatabaseConnection connection3;
    public ObservableList<Table3> AvailableBooksList;
    public ResultSet resultSet5;
    public Text leastchosenbook;
    public Text popularbook;
    private Random random;
    //It is a method that change page back to the option scene once entered from the option scene
    public void back(ActionEvent event) throws IOException {
        DatabaseConnection.changeScene(event,"OptionScene.fxml");
    }
    //It is the method that load the table and assign the data as soon as you change to the available books page in the option page
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        mostBooked();
        leastChosenBook();
        connection3 = new DatabaseConnection();
        Connection connectDB4 = connection3.getConnection();
        String command5 = "select * from booksavailable";
        String command = "select book_name from popularity where number_of_time_booked = (select max(number_of_time_booked)from popularity)";
        try{
            AvailableBooksList = FXCollections.observableArrayList();
            resultSet5 = connectDB4.createStatement().executeQuery(command5);
            while (resultSet5.next()){
                AvailableBooksList.add(new Table3(resultSet5.getString(1),resultSet5.getString(2),resultSet5.getInt(3)));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        ColBookId2.setCellValueFactory(new PropertyValueFactory<>("Book_id"));
        ColNumberAvailable2.setCellValueFactory(new PropertyValueFactory<>("Number_books_available"));
        ColBookName2.setCellValueFactory(new PropertyValueFactory<>("Book_name"));
        table3TableView.setItems(null);
        table3TableView.setItems(AvailableBooksList);
    }
    //It is am method that set the most booked books from the table in the label of most popular books in the available books page
    public void mostBooked(){
        String mostBooked;
        connection3 = new DatabaseConnection();
        Connection connection = connection3.getConnection();
        String command = "select book_name from popularity where number_of_time_booked = (select max(number_of_time_booked)from popularity)";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                mostBooked = resultSet.getString("book_name");
                popularbook.setText(mostBooked);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    //it is the method that set the least choosen books in the available books page besides its label
    public void leastChosenBook(){
        String leastChosen;
        connection3 = new DatabaseConnection();
        Connection connection = connection3.getConnection();
        String command = "select book_name from popularity where number_of_time_booked = (select min(number_of_time_booked)from popularity)";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                leastChosen = resultSet.getString("booK_name");
                leastchosenbook.setText(leastChosen);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

}
