package com.example.demo18;


import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;


import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;




public class Form   {
    //List of button and text field present on the form scene
    public Button submitbutton;
    public Button logoutbutton;
    public TextField bookLabel;
    public Button getLabel;
    public TextField bookid;
    public TextField booktype;
    public TextField studentname;
    public TextField studentid;
    public LocalDate borrowDate1 = LocalDate.now();

    //Method to change the scene or page to the option page
    public void toOptionScene(ActionEvent event) throws IOException {
        DatabaseConnection.changeScene(event, "OptionScene.fxml");
    }
    //Method for submitting the data like number of books and student id to the database if fields are not empty also contain method to check if books are available in the database using the chekerForForm method
    public void submit(){

        if (!studentname.getText().isEmpty() && !studentid.getText().isEmpty() && !booktype.getText().isEmpty() &&
                !bookid.getText().isEmpty() && !studentname.getText().isEmpty()&&!bookLabel.getText().isEmpty()){
            if(MyException.checkIfInteger(studentid.getText()) &&!MyException.checkIfInteger(studentname.getText())) {
                if (numberBooksAvailable() > 0 && CheckerForForm() && !ifLimitReached()) {

                    borrowDate1 = LocalDate.now();
                    DatabaseConnection connectionNow = new DatabaseConnection();
                    Connection connectionDB = connectionNow.getConnection();

                    String commandQuery = "insert into booked_books(student_ID,student_name," +
                            "book_type,book_id,date_borrowed,Librarian_Issued,Book_Label)values(?,?,?,?,?,?,?)";


                    try {
                        PreparedStatement pst = connectionDB.prepareStatement(commandQuery);

                        pst.setString(1, studentid.getText());
                        pst.setString(2, studentname.getText());
                        pst.setString(3, booktype.getText());
                        pst.setString(4, bookid.getText());
                        pst.setString(5, String.valueOf(borrowDate1));
                        pst.setString(6, LoginPage.getUserName());
                        pst.setString(7, bookLabel.getText());
                        pst.executeUpdate();
                        updateStudentCount();
                        updateBookAvailableLabel();
                        updateCount();
                        updatePopularity();

                        studentid.setText("");
                        studentname.setText("");
                        booktype.setText("");
                        bookid.setText("");
                        bookLabel.setText("");
                        connectionDB.close();
                        pst.close();


                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                } else if (numberBooksAvailable() == 0 && CheckerForForm()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("The book is depleted from the library");
                    alert.show();
                } else if (ifLimitReached()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Can not borrow any other book");
                    alert.show();}
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("The books ID and Name not available in the Library");
                    alert.show();
                }
            }else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Wrong data type");
                alert.show();
            }

        }
         else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Library Management System");
            alert.setContentText("Fill empty spaces");
            alert.show();
        }

    }
    //Method use to check if the book are available in the database before details in the submit method is submitted
    public boolean CheckerForForm(){
        boolean isPresent1 = false;
        DatabaseConnection connection5 = new DatabaseConnection();
        Connection connectionDB5 = connection5.getConnection();
        String command = "select * from booksavailable where book_name = ? and book_id=?";
        try{
            PreparedStatement preparedStatement5 = connectionDB5.prepareStatement(command);
            preparedStatement5.setString(1,booktype.getText());
            preparedStatement5.setString(2,bookid.getText());
            ResultSet set5 = preparedStatement5.executeQuery();
            if(set5.next()){
                isPresent1 = true;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return isPresent1;
    }
    //The method decrease the number of books in the database when the books are booked is declared in the submit method/function
    public void updateCount(){
        DatabaseConnection databaseConnection8 = new DatabaseConnection();
        Connection connectionDB8 = databaseConnection8.getConnection();

        String command = "update booksavailable set number_book_available = number_book_available - 1 where book_id = ?";
        try {
            PreparedStatement pst8 = connectionDB8.prepareStatement(command);
            pst8.setString(1,bookid.getText());
            pst8.executeUpdate();
            connectionDB8.close();
            pst8.close();
        }catch (SQLException e){
            e.printStackTrace();

        }

    }
    //Is the method that give out the number of books specifically to the number of books given to the books type and id in the form
    //The number of books are compared in the submit method above to be greater than zero so to check if the book is not depleted
    public  int numberBooksAvailable() {
        DatabaseConnection connection5 = new DatabaseConnection();
        Connection connectionDB5 = connection5.getConnection();
        String command = "select * from booksavailable where book_name = ? and book_id=?";
        int bookAvailable = 0;
        try {
            PreparedStatement preparedStatement5 = connectionDB5.prepareStatement(command);
            preparedStatement5.setString(1, booktype.getText());
            preparedStatement5.setString(2, bookid.getText());
            ResultSet set5 = preparedStatement5.executeQuery();
            if (set5.next()) {
                bookAvailable = set5.getInt(3);
            }
            connectionDB5.close();
            preparedStatement5.close();
            set5.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookAvailable;
    }
    public void aSignLabel(){
        if(!bookid.getText().isEmpty()) {
            DatabaseConnection databaseConnection = new DatabaseConnection();
            Connection connection = databaseConnection.getConnection();
            String command = "select book_label from book_available_label where status_of_book is null and book_id = ? order by RAND() limit 1";
            try {
                PreparedStatement preparedStatement = connection.prepareStatement(command);

                preparedStatement.setString(1, bookid.getText());
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String bookLabel1 = resultSet.getString(1);
                    bookLabel.setText(bookLabel1);
                }
                connection.close();
                preparedStatement.close();
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill the book ID Field");
            alert.show();
        }

    }
    //This method increment the number of time a book that is booked by one in the popularity table in the database to determine the popular book and the least popular book
    //depending on the number present on the attribute of the number of time booked
    public void updatePopularity(){
        DatabaseConnection connection = new DatabaseConnection();
        Connection connection1 = connection.getConnection();
        String command = "update popularity set number_of_time_booked = number_of_time_booked + 1 where book_name = ?";
        try {
            PreparedStatement preparedStatement = connection1.prepareStatement(command);
            preparedStatement.setString(1,booktype.getText());
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void updateBookAvailableLabel() {
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command1 = "delete from book_available_label where book_label = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(command1);
            preparedStatement.setString(1, bookLabel.getText());
            preparedStatement.executeUpdate();
            connection.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void updateStudentCount(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command = "insert into student_count (student_id,count) values (?,1) ";
        String command1 = "select count(*) from student_count where student_id = ?";
        String command2 = "update student_count set count = count + 1 where student_id = ?";

        try{
            PreparedStatement preparedStatement1 = connection.prepareStatement(command1);
            preparedStatement1.setString(1,studentid.getText());
            ResultSet resultSet = preparedStatement1.executeQuery();
            if(resultSet.next()){
                int count = resultSet.getInt(1);
                if(count > 0){
                    PreparedStatement preparedStatement2 = connection.prepareStatement(command2);
                    preparedStatement2.setString(1,studentid.getText());
                    preparedStatement2.executeUpdate();
                    preparedStatement2.close();
                }else{
                    PreparedStatement preparedStatement = connection.prepareStatement(command);
                    preparedStatement.setString(1,studentid.getText());
                    preparedStatement.executeUpdate();
                    preparedStatement.close();
                }
            }
            connection.close();
            resultSet.close();
            preparedStatement1.close();

        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public int getStudentCount(){
        int count = 0;
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command = "select count from student_count where student_id = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            preparedStatement.setString(1,studentid.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                count = resultSet.getInt(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        return count;
    }
    public boolean ifLimitReached(){
        System.out.println(getStudentCount());
        return getStudentCount() == AdministratorLoggingIn.getReturnBookLimit();
    }
}
