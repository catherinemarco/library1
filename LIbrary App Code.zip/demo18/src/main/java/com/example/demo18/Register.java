package com.example.demo18;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class Register implements Initializable {

    public TextField username;
    public Button register;
    public  PasswordField password;
    public PasswordField confirmpassword;
    public PasswordField admin;
    public ListView<String> TextArea;
    public Button ChangePassword;
    public Button delete;
    private ObservableList<String> names;

    DatabaseConnection databaseConnection2;
    Connection connection2;

    public void goBackToOptionScene(ActionEvent event) throws IOException {

        DatabaseConnection.changeScene(event,"welcome.fxml");
    }
    public void setClear(){
        username.setText("");
        password.setText("");
        confirmpassword.setText("");

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       refresh();
    }
    public void setRegister() {
        if(!username.getText().isEmpty()&&!password.getText().isEmpty()&&!confirmpassword.getText().isEmpty()){
            if(comparePassword()&&!checkUserNamePresent()) {
                databaseConnection2 = new DatabaseConnection();
                connection2 = databaseConnection2.getConnection();

                String CommandRegister = "insert into userinfo(username,password1) values (?,?)";
                try {
                    PreparedStatement preparedStatement = connection2.prepareStatement(CommandRegister);
                    preparedStatement.setString(1, username.getText());
                    preparedStatement.setString(2, password.getText());
                    preparedStatement.executeUpdate();
                    refresh();
                    setClear();


                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else if (checkUserNamePresent()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("UserName is Already Present");
                alert.show();
            } else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("The password does not match the confirm password");
                alert.show();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill the Blank Space");
            alert.show();
        }
    }
    public boolean comparePassword(){
        return confirmpassword.getText().equals(password.getText());
    }
    public void loadToChangePassword(ActionEvent event)throws IOException{
        DatabaseConnection.changeScene(event,"AdministratorLoggingIn.fxml");
    }

    public boolean checkUserNamePresent(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();

        String command = "select * from userinfo";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                if(username.getText().equalsIgnoreCase(resultSet.getString(1))){
                    return true;
                }
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
public void refresh() {
        String username = "";
        DatabaseConnection connection = new DatabaseConnection();
        Connection connection1 = connection.getConnection();

        names = FXCollections.observableArrayList();
        String command = "select username from userinfo";
        try{
            PreparedStatement preparedStatement = connection1.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                username = resultSet.getString(1);
                if(resultSet.getString(1).equals("Administrator")){
                    continue;
                }
                names.add(username);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        TextArea.setItems(names);

    }
    public void setDelete() {
        if (!username.getText().isEmpty()) {
            if(checkUserNamePresent()&&!username.getText().equalsIgnoreCase("Administrator")){
            DatabaseConnection connection = new DatabaseConnection();
            Connection connection1 = connection.getConnection();
            String Command = "delete from userinfo where username = ?";
            try {
                PreparedStatement preparedStatement = connection1.prepareStatement(Command);
                preparedStatement.setString(1, username.getText());
                preparedStatement.executeUpdate();
                refresh();
                username.setText("");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            }else if(!checkUserNamePresent()){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("User Name Is Not Present");
                alert.show();
            }else if(username.getText().equalsIgnoreCase("Administrator")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Can Not delete key Info");
                alert.show();
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("The User Name is required for deletion process");
            alert.show();
        }
    }
}
