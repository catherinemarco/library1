package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.*;


public class LoginPage {

    public Button LoginButton;
    public Button clearButton;
    @FXML
    private TextField userField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Button exitbutton;
    public static String userName;
    //Is the method that is used to clear or delete username and password details in the login page
    public void clearText() {
        userField.setText("");
        passwordField.setText("");
    }
    //It is the command that used to close the program linked to the exit button in the login page
    public void loadToWelcomePage(ActionEvent event) throws IOException{
        DatabaseConnection.changeScene(event,"welcome.fxml");
    }
    //It is the function or method that check if the fields are not empty and if the username and password entered are valid as present in the user info table in database
    //Else the display an alert
    public void loggingIn(ActionEvent event) throws IOException  {
        if(!userField.getText().isEmpty() &&!passwordField.getText().isEmpty()){
            if(passwordField.getText().equals(getPassword())){
               DatabaseConnection.changeScene(event,"OptionScene.fxml");
           }else{
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setContentText("Wrong Credential");
               alert.show();
           }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please Fill the Blank Spaces");
            alert.show();
        }

    }
    public static String getUserName(){
        return userName;
    }

    public String getPassword(){
        String password = "";
        DatabaseConnection connection = new DatabaseConnection();
        Connection connection1 = connection.getConnection();

        String command = "select * from userinfo where username = ?";
        try {
            PreparedStatement preparedStatement = connection1.prepareStatement(command);
            preparedStatement.setString(1,userField.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
               password = resultSet.getString(2);
               userName =resultSet.getString(1);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return password;
    }
}