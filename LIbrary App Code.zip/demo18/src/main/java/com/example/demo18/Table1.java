package com.example.demo18;
//All the table class has only function that is th get data from the database and put into our table tha is created same for Table2 and Table3

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Table1 {
    public SimpleStringProperty Student_ID;
    public SimpleStringProperty Student_Name;
    public SimpleStringProperty BookBorrowed;
    public SimpleIntegerProperty Book_ID;
    public SimpleStringProperty BorrowedDate;
    public SimpleStringProperty Librarian;
    public SimpleStringProperty BookLabel;


    public Table1(String Student_ID, String Student_Name, String BookBorrowed,
                  int Book_ID, String BorrowedDate,String Librarian, String BookLabel){
        this.Student_ID = new SimpleStringProperty(Student_ID);
        this.Student_Name = new SimpleStringProperty(Student_Name);
        this.BookBorrowed = new SimpleStringProperty(BookBorrowed);
        this.Book_ID = new SimpleIntegerProperty(Book_ID);
        this.BorrowedDate = new SimpleStringProperty(BorrowedDate);
        this.Librarian = new SimpleStringProperty(Librarian);
        this.BookLabel = new SimpleStringProperty(BookLabel);

    }

    public String getBookLabel() {
        return BookLabel.get();
    }

    public SimpleStringProperty bookLabelProperty() {
        return BookLabel;
    }

    public void setBookLabel(String bookLabel) {
        this.BookLabel.set(bookLabel);
    }

    public String getStudent_ID() {
        return Student_ID.get();
    }

    public void setStudent_ID(int student_ID) {
       this.Student_ID = new SimpleStringProperty();
    }

    public String getStudent_Name() {
        return Student_Name.get();
    }

    public void setStudent_Name(String student_Name) {
        this.Student_Name = new SimpleStringProperty(student_Name);
    }

    public String getBookBorrowed() {
        return BookBorrowed.get();
    }

    public void setBookBorrowed(String bookBorrowed) {
        this.BookBorrowed = new SimpleStringProperty(bookBorrowed);
    }

    public int getBook_ID() {
        return Book_ID.get();
    }

    public void setBook_ID(int book_ID) {
        this.Book_ID = new SimpleIntegerProperty(book_ID);
    }

    public String getBorrowedDate() {
        return BorrowedDate.get();
    }

    public void setBorrowedDate(String borrowedDate) {
        this.BorrowedDate = new SimpleStringProperty(borrowedDate);
    }

    public String getLibrarian() {
        return Librarian.get();
    }

    public void setLibrarian(String librarian) {
        this.Librarian = new SimpleStringProperty(librarian);
    }




}
