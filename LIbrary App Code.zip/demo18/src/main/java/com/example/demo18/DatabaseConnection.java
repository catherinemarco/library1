package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;


public class DatabaseConnection {
    //To obtain the database link from the MySql DataBase
    public Connection databaseLink;
    //Method for to get the connection to the database
    public Connection getConnection(){
        String username = "root";
        String password = "Tennyson1.";
        String url = "jdbc:mysql://localhost:3306/library_management_system" ;

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            databaseLink = DriverManager.getConnection(url,username,password);
        }catch (Exception e){
            e.printStackTrace();
        }
        return databaseLink;

    }
    //Method enabling to change page in the program by passing out certain fxml file like example "BookedBooks.fxml"
    public static void changeScene(ActionEvent event, String fxmlFile) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(DatabaseConnection.class.getResource(fxmlFile));
        Stage stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.show();
    }
}
