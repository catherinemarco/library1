package com.example.demo18;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

public class ReturnForm {
    public TextField studentid;
    public TextField bookid;
    public Button submitbutton;
    public LocalDate returnDate = LocalDate.now();
    public TextField bookLabel1;
    private String BookedDate;
    public int numberOfDays;
    public IntegerProperty maxDaysBooked = new SimpleIntegerProperty();
    LoginPage loginPage1 = new LoginPage();
    private String BookLabel;




    public  void backToOption(ActionEvent event) throws Exception{
        DatabaseConnection.changeScene(event,"OptionScene.fxml");
    }
    //It is a method that check if the user had book that type of book in the database after checking the the fields are not empty if so it will delete
    //the entry in the booked database and assign it to the return book table in the database
    public void returnCommand() {
        if(!studentid.getText().isEmpty()&&!bookid.getText().isEmpty()){
            if(checkerIfPresent()){
                DatabaseConnection connection2 = new DatabaseConnection();
                Connection connectDB2 = connection2.getConnection();

                String commandInsert = "insert into returnbooks(student_ID,student_name,book_type,book_id,date_returned" +
                        ",date_it_was_booked,booklabel,librarian,librarian_received)values(?,?,?,?,?,?,?,?,?)";
                String commandSelect = "select * from booked_books where student_ID = ? and book_id = ? and Book_Label = ?";
                try{
                    PreparedStatement preparedStatement = connectDB2.prepareStatement(commandSelect);
                    preparedStatement.setString(1,studentid.getText());
                    preparedStatement.setString(2,bookid.getText());
                    preparedStatement.setString(3,bookLabel1.getText());
                    ResultSet resultSet = preparedStatement.executeQuery();
                    PreparedStatement pst2 = connectDB2.prepareStatement(commandInsert);
                    if(resultSet.next()){
                        String StudentName = resultSet.getString(2);
                        String BookName = resultSet.getString(3);
                        BookLabel = resultSet.getString(7);
                        String Librarian = resultSet.getString(6);
                        BookedDate = resultSet.getString(5);

                        pst2.setString(1,studentid.getText());
                        pst2.setString(2,StudentName);
                        pst2.setString(3,BookName);
                        pst2.setString(4,bookid.getText());
                        pst2.setString(5,String.valueOf(returnDate));
                        pst2.setString(6,BookedDate);
                        pst2.setString(7,BookLabel);
                        pst2.setString(8,Librarian);
                        pst2.setString(9, LoginPage.getUserName());
                        pst2.executeUpdate();
                    }
                    borrowTimeLimit();
                    updateReturnCount();
                    decrementStudentCount();
                    updateReturnCount();
                    addTheLabelBack();
                    deleteQuery();
                    bookid.setText("");
                    studentid.setText("");
                    bookLabel1.setText("");
                    preparedStatement.close();
                    pst2.close();
                    connectDB2.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("The Student Did not Book The Book");
                alert.show();
            }

        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill the empty fields");
            alert.show();
        }
    }//Method that is initiated in the return command method above that delete the data in the booked books
    public void deleteQuery(){
        DatabaseConnection databaseConnection1 = new DatabaseConnection();
        Connection connectionDB1 = databaseConnection1.getConnection();
        String commandDelete ="delete from booked_books where student_ID = ? and book_id = ? and Book_label = ?";
        try {
            PreparedStatement preparedStatement = connectionDB1.prepareStatement(commandDelete);
            preparedStatement.setString(1,studentid.getText());
            preparedStatement.setString(2,bookid.getText());
            preparedStatement.setString(3,BookLabel);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connectionDB1.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    //Its is the command that check if the the book is present in the database table where booked books are stored
    public boolean checkerIfPresent(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String commandCheck = "select * from booked_books where student_ID = ? and book_id = ? and book_label = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(commandCheck);
            preparedStatement.setString(1,studentid.getText());
            preparedStatement.setString(2,bookid.getText());
            preparedStatement.setString(3,bookLabel1.getText());
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return true;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }//It is the method that increase thhe number of books by one in the quantity in the table of available books as per book is return by the librian
    //it is initiated also in the returnCommand method above
    public void updateReturnCount(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();

        String command = "update booksavailable set number_book_available = number_book_available + 1 where book_id = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            preparedStatement.setString(1,bookid.getText());
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public boolean borrowTimeLimit(){
        boolean status = false;
        LocalDate localDate = LocalDate.parse(BookedDate);
        Period period =Period.between(localDate,returnDate);
        numberOfDays = period.getDays();
        if(numberOfDays > getNumberOfDays()){
            status = true;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Did not return on time the book was taken on: "+BookedDate);
            alert.show();
        }
        return status;
    }
    public static int getNumberOfDays(){
        int number = 0;
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command = "select * from _limit";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                number = Integer.parseInt(resultSet.getString(2));
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return number;
    }
    public void addTheLabelBack(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String command1 = "select * from booked_books where book_label = ?";
        String command  = "insert into book_available_label(book_id,book_name,book_label,status_of_book)" +
                "values (?,?,?,?)";
        try {
            PreparedStatement preparedStatement1 = connection.prepareStatement(command1);
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            preparedStatement1.setString(1,bookLabel1.getText());
            ResultSet resultSet = preparedStatement1.executeQuery();
            while (resultSet.next()){
                preparedStatement.setString(1,bookid.getText());
                preparedStatement.setString(2,resultSet.getString(3));
                preparedStatement.setString(3,bookLabel1.getText());
                preparedStatement.setString(4,"assigned");
                preparedStatement.executeUpdate();

            }
            resultSet.close();
            preparedStatement.close();
            preparedStatement1.close();
            connection.close();

        }catch (SQLException e){
            e.printStackTrace();
        }

    }
    public void decrementStudentCount(){
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();
        String Command = "update student_count set count = count - 1 where student_id = ?";
        try{
          PreparedStatement preparedStatement = connection.prepareStatement(Command);
          preparedStatement.setString(1,studentid.getText());
          preparedStatement.executeUpdate();
          connection.close();
          preparedStatement.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }




}
