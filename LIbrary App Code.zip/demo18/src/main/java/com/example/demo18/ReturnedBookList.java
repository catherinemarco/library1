package com.example.demo18;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ReturnedBookList implements Initializable  {

    public  TableView<Table2> tableView;
    public  TableColumn<Table2,String> ColStudent_ID1;
    public  TableColumn<Table2,String> ColStudent_Name1;
    public  TableColumn<Table2,String> ColBookBorrowed1;
    public  TableColumn<Table2,Integer> ColBook_ID1;
    public  TableColumn<Table2,String> ColReturnDate;
    public  TableColumn<Table2,String> ColDateWasBooked;
    public TableColumn<Table2,String> ColBookLabel1;
    public TableColumn<Table2,String> ColLibrarian1;
    public TableColumn<Table2,String> ColLibrarian2;



    private ObservableList<Table2> returnBooksList;
    //It is the method that load the table and assign the data as soon as you change to the return books list page in the option page

    public void initialize(URL url, ResourceBundle resourceBundle) {
        DatabaseConnection connection2 = new DatabaseConnection();
        Connection connectDB = connection2.getConnection();
        String command4 = "select * from returnbooks";

        try{
            returnBooksList = FXCollections.observableArrayList();
            ResultSet resultSet1 = connectDB.createStatement().executeQuery(command4);
            while (resultSet1.next()) {
                returnBooksList.add(new Table2(resultSet1.getString(1), resultSet1.getString(2), resultSet1.getString(3),
                        resultSet1.getInt(4), resultSet1.getString(5), resultSet1.getString(6),resultSet1.getString(7),resultSet1.getString(8),
                        resultSet1.getString(9)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        ColStudent_ID1.setCellValueFactory(new PropertyValueFactory<>("Student_ID1"));
        ColStudent_Name1.setCellValueFactory(new PropertyValueFactory<>("Student_Name1"));
        ColBookBorrowed1.setCellValueFactory(new PropertyValueFactory<>("BookBorrowed1"));
        ColBook_ID1.setCellValueFactory(new PropertyValueFactory<>("Book_ID1"));
        ColReturnDate.setCellValueFactory(new PropertyValueFactory<>("Date_returned"));
        ColDateWasBooked.setCellValueFactory(new PropertyValueFactory<>("Date_was_booked"));
        ColBookLabel1.setCellValueFactory(new PropertyValueFactory<>("BookLabel"));
        ColLibrarian1.setCellValueFactory(new PropertyValueFactory<>("Librarian"));
        ColLibrarian2.setCellValueFactory(new PropertyValueFactory<>("Librarian2"));
        tableView.setItems(null);
        tableView.setItems(returnBooksList);
    }//Method that go back from the return list to option page
    public void goBack1(ActionEvent event) throws IOException {
        DatabaseConnection.changeScene(event,"OptionScene.fxml");
    }
}