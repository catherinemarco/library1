package com.example.demo18;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Welcome {
    public Button back;
    public Button administratorButton;
    public PasswordField adminPassword;


    public void setAdministratorButton1(ActionEvent event) throws IOException{
        if(checkForAdministratorPassword(event) && !adminPassword.getText().isEmpty()) {
            DatabaseConnection.changeScene(event, "register.fxml");
        }else if(adminPassword.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Fill the Blanks Spaces");
            alert.show();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Wrong password");
            alert.show();
        }
    }
    public void exitCommand1(){
        Stage stage = (Stage)back.getScene().getWindow();
        stage.close();
    }
    public void set(ActionEvent event) throws IOException{
        DatabaseConnection.changeScene(event,"LoginPage.fxml");
    }
    private boolean checkForAdministratorPassword(ActionEvent event) {
        DatabaseConnection databaseConnection = new DatabaseConnection();
        Connection connection = databaseConnection.getConnection();

        String command = "select password1 from userinfo where username = 'Administrator'";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(command);
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next())
                if(adminPassword.getText().equals(resultSet.getString(1))){
                    return true;
                }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
}
